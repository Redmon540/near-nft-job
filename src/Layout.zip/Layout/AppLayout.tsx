import React from "react";

import { AppLayoutWrapper } from "./AppLayout.styled";

// -----------------------------------------------------------

const Layout = ({ children }: any) => {
  return (
    <AppLayoutWrapper>
      {children}
    </AppLayoutWrapper>
  );
};

export default Layout;
