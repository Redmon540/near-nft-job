import styled from "styled-components";

// -------------------------------------------------------
export const AppLayoutWrapper = styled.div`
  position: relative;

  display: flex;
  flex-direction: column;
  // align-items: center;

  // background: #020c1a;
`;
